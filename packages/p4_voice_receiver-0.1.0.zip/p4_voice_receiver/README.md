# P4 hlasové vzkazy

Lokální přijímač pro experimentální komponentu ESPHome `voice_recorder`.
Ukládá desetisekundové mono WAV (48 kHz, 16 bit) do `/media/vzkazy`.
Přehrávání je přes přihlášený Home Assistant: **Média → Moje média → vzkazy**.

## Instalace v Home Assistant OS

1. Zkopírujte celou složku `p4_voice_receiver` do sdílené složky `addons`
   v HA OS, například přes Samba share. Výsledek má být
   `/addons/p4_voice_receiver/config.yaml` a vedle něj `Dockerfile` a `server.py`.
   Nejde o `/config/addons` ani o soubory na hostiteli Proxmox.
2. V obchodě s doplňky/aplikacemi obnovte nabídku (nabídka ⋮ → kontrola
   aktualizací). V místních doplňcích najděte **P4 hlasove vzkazy** a instalujte.
   První instalace sestaví kontejner a potřebuje internet pro základní obraz.
3. Vygenerujte náhodný klíč o 64 malých hexadecimálních znacích, například
   v Pythonu na PC:

   ```sh
   python -c "import secrets; print(secrets.token_hex(32))"
   ```

4. Klíč vložte do položky `token` v konfiguraci doplňku. Stejný klíč vložte
   do ESPHome `secrets.yaml` jako `voice_receiver_token`. Není to API klíč HA.
5. Ponechte síťový port 8099 a `max_recordings: 100`. Spusťte doplněk.
   Log má obsahovat `Receiver ready on port 8099; destination /media/vzkazy`.
6. Ve firmware nastavte `voice_receiver_ip` na IPv4 adresu **virtuálního
   počítače HA OS**, nikoli Proxmoxu, ESP32 nebo interní adresu kontejneru.

Podrobnosti firmware a testu jsou v `ETAPA_D2_VZKAZY.md` v kořeni projektu.

## Provoz

- Přijímá pouze `POST /recordings`, s hlavičkou `Authorization: Bearer …`,
  typem `application/octet-stream` a přesně 960 000 bajty PCM S16LE mono 48 kHz.
- Nahrávka se publikuje až po úplném přenosu a uzavření WAV. HTTP 201 potvrzuje
  zápis; neúplný přenos se zahodí. K souborům doplněk neposkytuje webový přístup.
- Název obsahuje čas **UTC** a náhodnou příponu. Například čas 15:30 UTC
  odpovídá v Praze během letního času 17:30. WAV má 960 044 bajtů.
- Při dosažení limitu nahrávek se další odmítají (507); staré soubory se
  automaticky nemažou. Před zvýšením limitu nebo dalším záznamem je archivujte
  nebo odstraňte ze složky médií. Výchozích 100 souborů zabere přibližně 96 MB.
- Pouze důvěryhodná místní síť: přenos HTTP není šifrovaný. Token chrání příjem
  před požadavky bez klíče, nechrání zvuk proti odposlechu sítě. Port nevystavujte
  do internetu. Používá se `/media`, nikoli veřejná složka `/config/www`.
- Po chybě sítě může být soubor uložený, i když deska nedostala potvrzení.
  Než pokus zopakujete, podívejte se do médií. Automatické opakování není zapnuté.

## Ověření

Síťové testy přijímače lze spustit pomocí `python test_server.py` z kopie projektu
na PC. Docker obraz a instalaci v Supervisoru je nutné ověřit na HA OS;
lokálně nebyl dostupný Docker. Toto není oficiální doplněk Home Assistantu.

Zdroje: [lokální doplňky](https://contributors.home-assistant.io/apps/first-app/),
[konfigurace a mapování médií](https://contributors.home-assistant.io/apps/reference/configuration/),
[média HA OS](https://www.home-assistant.io/more-info/local-media/setup-media/).
